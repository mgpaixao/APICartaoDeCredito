﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APICartaoDeCredito.Models
{
    public class ClienteDados
    {
        public int Id { get; set; } //Chave primária
        public string Email { get; set; }
        public string CardNumber { get; set; }
    }
}
